<!-- FOOTER -->
    <footer class="text-center">
        <div class="footer-below">
            <div class="container">
            Created by <a href=""><b>Group 5</b></a>  <b>of CSE370 Section 7</b>
            </div>
        </div>
    </footer>
